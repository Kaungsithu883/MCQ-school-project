import java.util.Scanner;

public class HNDlvl4 {
    public static void main(String[] args) {
        System.out.println("***Welcome to ABC Learning Center***");
        System.out.println("***Get ready to do MCQ :) good-luck***");
        System.out.println("***Enter Your Name***");
        Scanner sc = new Scanner(System.in);
        String name = sc.nextLine();
        choosequestion Q = new choosequestion();
        Q.remakeg();
        System.out.println("Your name is " +name);
    }

}