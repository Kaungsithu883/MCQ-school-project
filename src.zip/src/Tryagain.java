import java.util.Scanner;

public class Tryagain {
    public static void Retry() {
        System.out.println("You can choose the two options for that.");
        System.out.println("Click 1 for re-answer the question.");
        System.out.println("Click 2 for the Session End.");
        Scanner sc = new Scanner(System.in);
        int Retry = sc.nextInt();
        if(Retry ==1){
            choosequestion Q = new choosequestion();
            Q.remakeg();
        }
        else {
            System.exit(0);
        }
    }
}
