public class Calculate {
    public static void calculate(int count,int wrong){
        double avgresult = count*10;
        System.out.println("all of 10 questions, You answered" +count+ " questions are correct and " +wrong+ "wrong questions");
        System.out.println("Then you get"+ avgresult+"% mark");
        Tryagain a = new Tryagain();
        a.Retry();
    }
}
