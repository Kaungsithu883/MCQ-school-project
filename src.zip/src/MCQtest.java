import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;


public class MCQtest {
    static int count = 0;
    static int wrong = 0;
    public static void Question(int choice){

        switch (choice){
            case 1:{
                String csv = "src\\MCQprojectplan\\ABCproject.csv";
                BufferedReader br = null;
                String space;
                String comma = ",";

                try{
                    br = new BufferedReader(new FileReader(csv));
                    while ((space = br.readLine())!=null){
                        String[] Question = space.split(comma);
                        System.out.println(Question[0]+"\n"+Question[1]+"\n"+Question[2]+"\n"+Question[3]+"\n"+Question[4]);
                        Scanner sc = new Scanner(System.in);
                        String answer = sc.next();
                        if (Question[5].equals(answer)) {
                            System.out.println("Correct Answer");
                            count++;
                        }
                        else{
                            System.out.println("Wrong Answer");
                            wrong++;
                        }
                    }
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                }catch (IOException e){
                    e.printStackTrace();
                }
            }
            break;
            case 2:{
                String csv = "src\\MCQprojectplan\\Question2.csv";
                BufferedReader br = null;
                String space;
                String comma = ",";

                try{
                    br = new BufferedReader(new FileReader(csv));
                    while ((space=br.readLine())!=null){
                        String[] Question = space.split(comma);
                        System.out.println(Question[0]+"\n"+Question[1]+"\n"+Question[2]+"\n"+Question[3]+"\n"+Question[4]);
                        Scanner sc = new Scanner(System.in);
                        String answer = sc.next();
                        if (Question[5].equals(answer)) {
                            System.out.println("Correct Answer");
                            count++;
                        }
                        else{
                            System.out.println("Wrong Answer");
                            wrong++;
                        }
                    }
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                }catch (IOException e){
                    e.printStackTrace();
                }
            }

            break;
            case 3:{
                String csv = "src\\MCQprojectplan\\Question3.csv";
                BufferedReader br = null;
                String space;
                String comma = ",";

                try{
                    br = new BufferedReader(new FileReader(csv));
                    while ((space=br.readLine())!=null){
                        String[] Question = space.split(comma);
                        System.out.println(Question[0]+"\n"+Question[1]+"\n"+Question[2]+"\n"+Question[3]+"\n"+Question[4]);
                        Scanner sc = new Scanner(System.in);
                        String answer = sc.next();
                        if (Question[5].equals(answer)) {
                            System.out.println("Correct Answer");
                            count++;
                        }
                        else{
                            System.out.println("Wrong Answer");
                            wrong++;
                        }
                    }
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                }catch (IOException e){
                    e.printStackTrace();
                }
            }
            break;
            default:
                System.out.println("errors");
        }
        Calculate C = new Calculate();
        C.calculate(count,wrong);
    }
}


