import java.util.Scanner;

public class choosequestion {
    public static void remakeg(){
        System.out.println("Choose MCQ Set");
        System.out.println("1.SAD");
        System.out.println("2.HTML");
        System.out.println("3.JAVA");
        Scanner sc = new Scanner((System.in));
        int choice = sc.nextInt();
        MCQtest MCQtest = new MCQtest ();
        MCQtest.Question(choice);
    }
}
